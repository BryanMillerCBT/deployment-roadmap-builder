# Handoff: Deployment Roadmap Builder — Certinia Design System Redesign

## Overview

This package contains a high-fidelity redesign of the **Deployment Roadmap Builder** — a Vite + Vanilla JS Gantt chart tool used by CSMs to build and share customer deployment roadmaps. The existing codebase lives at:

> `https://github.com/BryanMillerCBT/deployment-roadmap-builder`

The design applies the **Certinia Design System** (brand colors, typography, component patterns) while adding new UX features: a stats bar, collapsible workstream rows, a resizable label column, inline workstream renaming, and redesigned Gantt bar interactions.

---

## About the Design Files

The files in this bundle (`Deployment Roadmap Builder.html`, `roadmap-app.jsx`, `tweaks-panel.jsx`) are **design reference prototypes created in HTML/React** — they show the intended look, feel, and interactions but are **not production code to copy directly**.

The task is to **recreate these designs in the existing Vite + Vanilla JS codebase** (`src/styles/main.css`, `src/render.js`, `src/modals.js`, `src/interactions.js`) using its established patterns. The prototype uses React/JSX for development speed — the target codebase uses vanilla JS with inline HTML string rendering. Port the logic and styles, not the framework.

---

## Fidelity

**High-fidelity.** The prototype is pixel-precise with final colors, typography, spacing, and interactions. Recreate the UI to match as closely as possible using the existing codebase's patterns.

---

## Color Themes

The design supports two themes, toggled by a `data-theme` attribute on `<html>`:

| Theme | Value | Description |
|---|---|---|
| Gradient (light) | `gradient` | White bg, colorful gradient top bar |
| Gradient Dark | `gradient-dark` | Dark `#000c17` bg, same gradient top bar |

Both themes share these CSS custom properties (defined on `:root`, overridden per theme):

```css
:root {
  --font-display: 'Bodoni Moda', Georgia, serif;
  --font-body:    'Poppins', sans-serif;

  /* Snow base — override with [data-theme] */
  --bg:          #ffffff;
  --bg-2:        #f5f7fa;
  --bg-3:        #eceff1;
  --text:        #000c17;
  --text-2:      #1f2933;
  --text-3:      #7b8794;
  --border:      #d1d7dd;
  --border-2:    #e3e7eb;
  --accent:      #000c17;       /* primary button bg */
  --accent-2:    #3927ff;       /* Certinia Blue — hover highlights */
  --accent-text: #ffffff;
  --current-m:   #3927ff;       /* current month column highlight */
  --shadow:      0 1px 4px rgba(0,0,0,.08), 0 4px 16px rgba(0,0,0,.06);
  --modal-over:  rgba(0,12,23,.45);
  --radius:      6px;
  --radius-lg:   10px;
  --gradient:    linear-gradient(90deg, #DCA0FF, #7EA5FF, #64F0FF);
}

[data-theme="gradient"] {
  /* Same as :root — exists so the top bar gradient override applies */
  --accent: #000c17;
}

[data-theme="gradient-dark"] {
  --bg:          #000c17;
  --bg-2:        #111c26;
  --bg-3:        #1f2933;
  --text:        #fbfcfd;
  --text-2:      #c1c9d1;
  --text-3:      #7b8794;
  --border:      #333f4b;
  --border-2:    #1f2933;
  --accent:      #6353ff;
  --accent-2:    #3927ff;
  --current-m:   #6353ff;
  --shadow:      0 1px 4px rgba(0,0,0,.3), 0 4px 16px rgba(0,0,0,.25);
  --modal-over:  rgba(0,0,0,.65);
}
```

**Both gradient themes share the same top bar gradient:**
```css
[data-theme="gradient"] .top-bar,
[data-theme="gradient-dark"] .top-bar {
  background: linear-gradient(90deg, #DCA0FF 0%, #7EA5FF 50%, #64F0FF 100%);
  border-bottom-color: transparent;
}
```

For the gradient top bar, override button and input styles to use dark text / semi-transparent backgrounds (see the prototype HTML for exact values).

---

## Typography

Add these Google Fonts to `index.html`:
```html
<link href="https://fonts.googleapis.com/css2?family=Bodoni+Moda:ital,opsz,wght@0,6..96,400;0,6..96,500;0,6..96,700;1,6..96,400&family=Poppins:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&display=swap" rel="stylesheet" />
```

| Use | Font | Size | Weight | Notes |
|---|---|---|---|---|
| Roadmap name input | Bodoni Moda | 15px | 500 | Italic placeholder |
| Stats percentage | Bodoni Moda | 20px | 600 | Display number |
| Body / UI | Poppins | 12–13px | 400/500 | All other text |
| Workstream name | Poppins | 12px | 600 | letter-spacing: -.01em |
| Month labels | Poppins | 10px | 500 | Uppercase, letter-spacing: .04em |
| Feature name (label col) | Poppins | 11px | 500 | Truncate with ellipsis |
| Bar label | Poppins | 10px | 500 | Truncate with ellipsis |

---

## Status Colors (Certinia-aligned)

Replace the existing status color definitions in `src/config.js` with:

```js
statuses: [
  { id: "not-started",     label: "Not Started",     color: "#606e7c", fill: "#eceff1", darkFill: "#3e4c59", darkColor: "#e3e7eb" },
  { id: "identified",      label: "Identified",      color: "#6353ff", fill: "#ede9ff", darkFill: "#3d35aa", darkColor: "#ffffff" },
  { id: "requirements",    label: "Requirements",    color: "#0065cc", fill: "#ddeeff", darkFill: "#0a4f9e", darkColor: "#ffffff" },
  { id: "in-progress",     label: "In Progress",     color: "#006fb5", fill: "#ddf4ff", darkFill: "#085c8a", darkColor: "#ffffff" },
  { id: "at-risk",         label: "At Risk",         color: "#b91c1c", fill: "#fde8e8", darkFill: "#922020", darkColor: "#ffffff" },
  { id: "on-hold",         label: "On Hold",         color: "#7a5800", fill: "#fff8db", darkFill: "#7a6200", darkColor: "#ffffff" },
  { id: "ready-to-deploy", label: "Ready to Deploy", color: "#3927ff", fill: "#e8e5ff", darkFill: "#3020cc", darkColor: "#ffffff" },
  { id: "deployed",        label: "Deployed",        color: "#00a37a", fill: "#d1faf0", darkFill: "#00614a", darkColor: "#ffffff" },
]
```

In dark mode, use `darkFill` as bar background and `darkColor` as bar text. White text on all colored dark fills ensures readability.

---

## Screens / Views

### 1. Top Bar

**Height:** 56px. **Background:** theme gradient (or white for non-gradient themes).

| Element | Detail |
|---|---|
| Logo | `public/logo-black.svg` (light themes) / `public/logo-white.svg` (dark). Height: 22px |
| Divider | 1px vertical line, `var(--border)`, height 24px |
| Roadmap name input | Bodoni Moda 15px, transparent bg, border appears on hover/focus. Min-width 220px |
| Spacer | `flex: 1` |
| Export JSON button | Ghost style (see Buttons) |
| Import JSON label | Ghost style, wraps `<input type="file">` |
| New button | Ghost style |
| Save button | Primary style |

**Gradient top bar overrides:** input gets `background: rgba(0,0,0,.12)`, buttons use semi-transparent white backgrounds with dark text.

---

### 2. Stats Bar

**Height:** auto (~52px). **Background:** `var(--bg)`. **Border-bottom:** `1px solid var(--border-2)`. **Padding:** 12px 20px.

| Element | Detail |
|---|---|
| Progress label | "XX%" in Bodoni Moda 20px/600 + "deployed" in Poppins 9px/500 uppercase |
| Progress track | 120px wide × 5px tall, `var(--bg-3)` background, `border-radius: 99px` |
| Progress fill | `background: #00db9a` (Certinia green), animates `width` on change |
| Feature count | "X/Y features" in Poppins 11px, `var(--text-3)` |
| Status pills | Flex row, gap 6px. Each pill: `border-radius: 99px`, `background: var(--bg-2)`, `border: 1px solid var(--border-2)`, padding 3px 8px 3px 5px |
| Pill dot | 9px circle, color = status fill (or gradient for deployed) |
| Pill label | 11px Poppins, `var(--text)` |
| Pill count | 11px Poppins 600, `var(--text)` |

Only show pills for statuses that have at least 1 feature.

---

### 3. Toolbar

**Height:** auto (~44px). **Background:** `var(--bg)`. **Border-bottom:** `1px solid var(--border-2)`. **Padding:** 10px 20px.

Left to right: `+ Add feature` (primary button), `+ Add workstream` (secondary button), workstream filter `<select>`, status filter `<select>`, spacer, `Export .pptx` (ghost button).

---

### 4. Legend

**Padding:** 8px 20px. **Border-bottom:** `1px solid var(--border-2)`.

Flex row, wrap, gap 10px. Each item: 10px × 10px square swatch (`border-radius: 3px`) + 11px Poppins label in `var(--text)`.

---

### 5. Gantt Chart

**Column structure** (CSS grid):
```
[labelWidth]px  [colWidth]px × 12
```
`labelWidth` defaults to 188px but is **user-resizable** (see Interactions). `colWidth` = 64px.

#### Release band row
One row above the month header. Each release spans multiple columns (`grid-column: span N`). Styled with the release's `bg` color and `color` for text. 10px Poppins, 600 weight, uppercase, letter-spacing .04em.

#### Month header row
`background: var(--bg-2)`. Month cells: 10px Poppins 500, `var(--text-2)`, centered. Current month cell: `background: var(--current-m)`, white text.

#### Label column header cell
Has a **resize handle** on its right edge:
- `position: absolute; right: 0; top: 0; bottom: 0; width: 6px; cursor: col-resize`
- Transparent background, turns semi-opaque accent color on hover

#### Workstream section
Each section has a header row + feature rows. Header row: `height: 38px`, `background: var(--bg-2)`, `border-bottom: 1px solid var(--border-2)`.

**Workstream header label cell** (sticky left, `z-index: 2`):
- Collapse chevron button (▾ rotates -90deg when collapsed)
- `+ feature` and (optionally) other action buttons — stacked vertically, `font-size: 9px`
- Color dot: 9px circle, workstream color
- Workstream name: 12px Poppins 600, `var(--text)`, `letter-spacing: -.01em`
  - `tabindex="0"`, `role="button"`, `aria-label="..., Press Enter to rename"`
  - **Double-click** or **Enter/Space** keypress activates inline edit (see Interactions)
  - Shows blue focus ring on keyboard focus

#### Feature rows
`height: 36px` (comfortable) or `28px` (compact). Grid matches header. `border-bottom: 1px solid var(--border-2)`. Hover: `background: var(--bg-2)`.

**Label cell** (sticky left): drag handle `⠿` (color `var(--text-3)`) + feature name (11px Poppins 500, `var(--text)`, truncated, pointer cursor, changes to `var(--accent-2)` on hover).

**Month cells:** alternating `.alt` cells get `background: rgba(0,0,0,.012)`. The cell at `feature.start` renders the bar.

#### Gantt bar

```
position: absolute
top: 6px (comfortable) / 4px (compact)
height: 24px (comfortable) / 18px (compact)
width: (end - start + 1) * colWidth - 8  px
left: 4px
border-radius: 4px
cursor: grab
overflow: hidden
```

Background: `status.fill` (light themes) / `status.darkFill` (dark). Text: `status.color` / `status.darkColor`. Border: `1px solid status.color` (no border for gradient/deployed).

**Three-dot resize grips** at each end:
- `display: flex; flex-direction: column; gap: 2px; width: 8px; cursor: ew-resize`
- Three `<span>` elements: `3px × 3px`, `border-radius: 50%`, `background: currentColor`
- `opacity: 0.5` at rest, `opacity: 1` on bar hover
- Left grip → resize start month; right grip → resize end month

**Bar label:** centered between grips, `overflow: hidden; text-overflow: ellipsis; pointer-events: none`

---

## Interactions & Behavior

### Resizable label column
- Mousedown on the resize handle (right edge of "Workstream / Feature" header): begin resize
- Set `document.body.style.cursor = "col-resize"` and `userSelect = "none"` during drag
- On mousemove: `newWidth = Math.max(100, Math.min(360, startWidth + dx))`
- Re-render grid with new `labelWidth` on each mousemove (or use a CSS variable update for performance)
- Restore cursor/userSelect on mouseup

### Gantt bar drag (move)
- Mousedown anywhere on the bar (not on resize grips): begin move drag
- Track `startX`, `origStart`, `origEnd`
- On mousemove: `monthDelta = Math.round(dx / colWidth)`, clamp 0–11, preserve span length
- On mouseup: commit to state + `persistState()`
- Add `body.is-dragging` class during drag (`cursor: grabbing`)

### Gantt bar resize
- Mousedown on left/right grip: begin resize drag
- Left grip: adjust `start` only, clamp to `[0, end]`
- Right grip: adjust `end` only, clamp to `[start, 11]`
- Same mousemove/mouseup pattern as move drag

### Gantt bar edit
- **Double-click** on bar → open edit modal for that feature

### Workstream inline rename
1. Workstream name is `tabindex="0"`, `role="button"`
2. **Double-click** or **Enter/Space** keypress → replace span with `<input>` containing current name
3. Input auto-focuses and selects all text
4. **Enter** or blur → trim, validate (non-empty), update workstream name in state + `persistState()`
5. **Escape** → cancel (restore original name, return to span)
6. Focus ring: `outline: 2px solid var(--accent); outline-offset: 2px` (`:focus-visible` only)

### Workstream collapse/expand
- Chevron button toggles collapsed state per workstream ID
- Chevron rotates: `transform: rotate(-90deg)` when collapsed
- Feature rows for that workstream are hidden when collapsed
- Button has `aria-expanded` attribute

### Progress stats bar
- Recalculate on every render: count features per status, compute `deployed / total * 100`
- Progress bar fill width animates: `transition: width .4s ease`

### Theme switching
- Apply `document.documentElement.setAttribute("data-theme", theme)` on change
- Logo src changes: dark themes → `logo-white.svg`, light themes → `logo-black.svg`
- Bar colors: use `darkFill`/`darkColor` when `theme === "gradient-dark"` (or any future dark theme)

### Row density
- Comfortable: feature row height 36px, bar height 24px, bar top 6px
- Compact: feature row height 28px, bar height 18px, bar top 4px

---

## Buttons

| Variant | Class | Background | Border | Text | Notes |
|---|---|---|---|---|---|
| Primary | `.btn-primary` | `var(--accent)` = `#000c17` | same | white | Hover: `filter: brightness(1.1)` |
| Secondary | `.btn-secondary` | `var(--bg)` | `var(--border)` | `var(--text)` | Hover: `var(--bg-2)` |
| Ghost | `.btn-ghost` | transparent | `var(--border)` | `var(--text-2)` | Hover: `var(--bg-2)`, text `var(--text)` |
| Danger | `.btn-danger` | `#fde8e8` | `#fca5a5` | `#b91c1c` | Hover: `#fecaca` |

All buttons: `font-size: 12px`, `font-weight: 500`, `padding: 6px 14px`, `border-radius: var(--radius)`, `font-family: Poppins`.

---

## Modals

**Overlay:** `position: fixed; inset: 0; background: var(--modal-over); backdrop-filter: blur(2px); z-index: 100`

**Modal box:** `background: var(--bg); border: 1px solid var(--border); border-radius: var(--radius-lg); padding: 24px; width: 380px; max-width: 95vw; box-shadow: var(--shadow)`

Entry animation:
```css
@keyframes modal-in {
  from { opacity: 0; transform: translateY(6px) scale(.98); }
  to   { opacity: 1; transform: translateY(0) scale(1); }
}
```

**Form labels:** 11px Poppins 500, `var(--text-2)`, uppercase, `letter-spacing: .05em`

**Month picker grid:** 6 columns, each button 10px Poppins 500. Selected: `background: var(--accent); color: #fff`. Hover: border turns `var(--accent)`.

**Feature modal fields:** name (text input), workstream (select), status (select), start month (grid), end month (grid). Delete button (danger, `margin-right: auto`) only shown when editing.

**Workstream modal fields:** name (text input), color (circle color swatches, 28px each, selected = 3px border). Delete button only shown when editing — guard: alert if workstream has features.

---

## Design Tokens Summary

```
Certinia Blue:      #3927ff
Certinia Green:     #00db9a  
Certinia Violet:    #6353ff
Gradient:           linear-gradient(90deg, #DCA0FF, #7EA5FF, #64F0FF)
Grey dark:          #000c17
Grey text:          #1f2933
Grey mid:           #7b8794
Grey border:        #d1d7dd
Grey surface:       #f5f7fa
Border radius sm:   6px
Border radius lg:   10px
```

---

## Assets

| File | Location | Usage |
|---|---|---|
| `logo-black.svg` | `assets/logo-black.svg` | Top bar, light themes |
| `logo-white.svg` | `assets/logo-white.svg` | Top bar, dark themes |

Copy both into the Vite project's `public/` folder so they're served at `/logo-black.svg` and `/logo-white.svg`.

---

## Files in This Package

| File | Purpose |
|---|---|
| `README.md` | This document — implementation spec |
| `Deployment Roadmap Builder.html` | Full hi-fi interactive prototype (open in browser) |
| `roadmap-app.jsx` | All React components — reference for logic and structure |
| `assets/logo-black.svg` | Certinia wordmark (black) |
| `assets/logo-white.svg` | Certinia wordmark (white) |

Open `Deployment Roadmap Builder.html` in a browser to interact with the reference design. The Tweaks panel (toolbar icon) lets you switch between **Gradient** and **Gradient Dark** themes, and toggle **Comfortable / Compact** row density.
