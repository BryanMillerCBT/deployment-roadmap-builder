// Deployment Roadmap Builder — Certinia Design System
// All React components in one file

const { useState, useRef, useEffect, useCallback } = React;

// ─── Constants ────────────────────────────────────────────────────────────────
const MONTHS = ["FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC","JAN"];
const CURRENT_MONTH = 2;
const COL_WIDTH = 64;
const LABEL_WIDTH = 188;

const RELEASES = [
  { label: "Winter 26", start: 0, end: 2,  bg: "rgba(57,39,255,0.07)", color: "#3927ff" },
  { label: "Spring 26", start: 3, end: 5,  bg: "rgba(0,135,255,0.07)", color: "#0087ff" },
  { label: "Summer 26", start: 6, end: 8,  bg: "rgba(0,219,154,0.07)", color: "#00a37a" },
  { label: "Winter 27", start: 9, end: 11, bg: "rgba(187,116,255,0.08)", color: "#7b44c4" },
];

const STATUSES = [
  { id: "not-started",     label: "Not Started",     color: "#606e7c", fill: "#eceff1", darkFill: "#3e4c59", darkColor: "#e3e7eb" },
  { id: "identified",      label: "Identified",      color: "#6353ff", fill: "#ede9ff", darkFill: "#3d35aa", darkColor: "#ffffff" },
  { id: "requirements",    label: "Requirements",    color: "#0065cc", fill: "#ddeeff", darkFill: "#0a4f9e", darkColor: "#ffffff" },
  { id: "in-progress",     label: "In Progress",     color: "#006fb5", fill: "#ddf4ff", darkFill: "#085c8a", darkColor: "#ffffff" },
  { id: "at-risk",         label: "At Risk",         color: "#b91c1c", fill: "#fde8e8", darkFill: "#922020", darkColor: "#ffffff" },
  { id: "on-hold",         label: "On Hold",         color: "#7a5800", fill: "#fff8db", darkFill: "#7a6200", darkColor: "#ffffff" },
  { id: "ready-to-deploy", label: "Ready to Deploy", color: "#3927ff", fill: "#e8e5ff", darkFill: "#3020cc", darkColor: "#ffffff" },
  { id: "deployed",        label: "Deployed",        color: "#00a37a", fill: "#d1faf0", darkFill: "#00614a", darkColor: "#ffffff" },
];

const WS_COLORS = ["#3927ff","#0087ff","#00db9a","#bb74ff","#00deff","#6353ff","#c0392b","#8a6700"];

const DEFAULT_WS = [
  { id: "staffing",   name: "Staffing",   color: "#3927ff" },
  { id: "delivery",   name: "Delivery",   color: "#0087ff" },
  { id: "partners",   name: "Partners",   color: "#00db9a" },
  { id: "operations", name: "Operations", color: "#bb74ff" },
];

const DEFAULT_FEATURES = [
  { id: 1, ws: "staffing",   name: "Work Planner Contouring", start: 0, end: 2,  status: "deployed" },
  { id: 2, ws: "staffing",   name: "Resource Forecasting",    start: 3, end: 5,  status: "ready-to-deploy" },
  { id: 3, ws: "delivery",   name: "Project Billing Rules",   start: 0, end: 3,  status: "in-progress" },
  { id: 4, ws: "delivery",   name: "Milestone Tracker",       start: 4, end: 7,  status: "identified" },
  { id: 5, ws: "partners",   name: "Partner Portal SSO",      start: 1, end: 4,  status: "requirements" },
  { id: 6, ws: "operations", name: "Expense Automation",      start: 3, end: 6,  status: "not-started" },
  { id: 7, ws: "operations", name: "Invoice Matching",        start: 7, end: 10, status: "at-risk" },
];

// ─── Helpers ──────────────────────────────────────────────────────────────────
function statusFor(id) {
  return STATUSES.find(s => s.id === id) || STATUSES[0];
}

function persist(data) {
  try { localStorage.setItem("certinia_roadmap", JSON.stringify(data)); } catch(_) {}
}

function load() {
  try {
    const raw = localStorage.getItem("certinia_roadmap");
    if (raw) return JSON.parse(raw);
  } catch(_) {}
  return null;
}

// ─── TopBar ───────────────────────────────────────────────────────────────────
function TopBar({ roadmapName, onNameChange, onNew, onSave, onExportJson, onImportJson, theme }) {
  const logoSrc = theme === "midnight" ? "assets/logo-white.svg" : "assets/logo-black.svg";
  return (
    <div className="top-bar">
      <img src={logoSrc} alt="Certinia" className="top-bar-logo" />
      <div className="top-bar-divider" />
      <input
        className="roadmap-name-input"
        value={roadmapName}
        onChange={e => onNameChange(e.target.value)}
        placeholder="Customer / roadmap name"
        style={{fontFamily:"'Bodoni Moda', Georgia, serif", fontStyle: roadmapName ? "normal" : "italic"}}
      />
      <div className="top-bar-spacer" />
      <button className="btn-ghost" onClick={onExportJson}>Export JSON</button>
      <label className="btn-ghost" style={{cursor:"pointer"}}>
        Import JSON
        <input type="file" accept=".json" onChange={onImportJson} style={{display:"none"}} />
      </label>
      <button className="btn-ghost" onClick={onNew}>New</button>
      <button className="btn-primary" onClick={onSave}>Save</button>
    </div>
  );
}

// ─── StatsBar ─────────────────────────────────────────────────────────────────
function StatsBar({ features }) {
  const counts = {};
  STATUSES.forEach(s => { counts[s.id] = 0; });
  features.forEach(f => { if (counts[f.status] !== undefined) counts[f.status]++; });
  const total = features.length;
  const deployed = counts["deployed"] || 0;
  const pct = total > 0 ? Math.round((deployed / total) * 100) : 0;

  const active = STATUSES.filter(s => counts[s.id] > 0);

  return (
    <div className="stats-bar">
      <div className="stats-progress-wrap">
        <div className="stats-progress-label">
          <span className="stats-pct">{pct}%</span>
          <span className="stats-pct-sub">deployed</span>
        </div>
        <div className="stats-track">
          <div className="stats-fill" style={{width: pct + "%"}} />
        </div>
        <span className="stats-count">{deployed}/{total} features</span>
      </div>
      <div className="stats-pills">
        {active.map(s => (
          <div key={s.id} className="stats-pill">
            <span className="stats-dot" style={{
              background: s.fill === "gradient"
                ? "linear-gradient(90deg,#DCA0FF,#7EA5FF,#64F0FF)"
                : s.fill,
              border: `1.5px solid ${s.color === "#606e7c" ? s.fill : s.color}`
            }} />
            <span className="stats-pill-label">{s.label}</span>
            <span className="stats-pill-count">{counts[s.id]}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Toolbar ──────────────────────────────────────────────────────────────────
function Toolbar({ workstreams, onAddFeature, onAddWs, filterWs, setFilterWs, filterStatus, setFilterStatus, onExportPptx }) {
  return (
    <div className="toolbar">
      <button className="btn-primary" onClick={() => onAddFeature(null)}>+ Add feature</button>
      <button className="btn-secondary" onClick={onAddWs}>+ Add workstream</button>
      <select className="toolbar-select" value={filterWs} onChange={e => setFilterWs(e.target.value)}>
        <option value="">All workstreams</option>
        {workstreams.map(w => <option key={w.id} value={w.id}>{w.name}</option>)}
      </select>
      <select className="toolbar-select" value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
        <option value="">All statuses</option>
        {STATUSES.map(s => <option key={s.id} value={s.id}>{s.label}</option>)}
      </select>
      <div style={{flex:1}} />
      <button className="btn-ghost" onClick={onExportPptx}>Export .pptx</button>
    </div>
  );
}

// ─── Legend ───────────────────────────────────────────────────────────────────
function Legend() {
  return (
    <div className="legend">
      {STATUSES.map(s => (
        <div key={s.id} className="legend-item">
          <span className="legend-swatch" style={{
            background: s.fill === "gradient"
              ? "linear-gradient(90deg,#DCA0FF,#7EA5FF,#64F0FF)"
              : s.fill,
            border: `1.5px solid ${s.color === "#606e7c" ? "#c1c9d1" : s.color}`
          }} />
          <span>{s.label}</span>
        </div>
      ))}
    </div>
  );
}

// ─── GanttBar ─────────────────────────────────────────────────────────────────
function GanttBar({ feature, colWidth, onEdit, onDragStart, onResizeStart, isDark, density }) {
  const st = statusFor(feature.status);
  const width = (feature.end - feature.start + 1) * colWidth - 8;
  const barH = density === "compact" ? 18 : 24;
  const barTop = density === "compact" ? 4 : 6;

  const isGradient = st.fill === "gradient";
  const bg = isGradient
    ? "linear-gradient(90deg,#DCA0FF,#7EA5FF,#64F0FF)"
    : (isDark ? st.darkFill : st.fill);
  const textColor = isGradient ? "#1f2933" : (isDark ? (st.darkColor || st.color) : st.color);
  const dotsColor = textColor;

  return (
    <div
      className="gantt-bar"
      style={{
        left: 4, width, top: barTop, height: barH,
        background: bg,
        border: `1px solid ${isGradient ? "transparent" : st.color}`,
        color: textColor,
        fontSize: density === "compact" ? 9 : 10,
        paddingLeft: 10, paddingRight: 10,
      }}
      onMouseDown={e => { if (e.target.dataset.resize) return; onDragStart(e, feature); }}
      onDoubleClick={e => { e.stopPropagation(); onEdit(feature.id); }}
      title={`${feature.name} — double-click to edit`}
    >
      <div
        className="bar-resize-dots"
        data-resize="l"
        onMouseDown={e => { e.stopPropagation(); onResizeStart(e, feature, "l"); }}
        style={{color: dotsColor}}
      >
        <span /><span /><span />
      </div>
      <span className="bar-label">{feature.name}</span>
      <div
        className="bar-resize-dots"
        data-resize="r"
        onMouseDown={e => { e.stopPropagation(); onResizeStart(e, feature, "r"); }}
        style={{color: dotsColor}}
      >
        <span /><span /><span />
      </div>
    </div>
  );
}

// ─── WsNameEditor ─────────────────────────────────────────────────────────────
function WsNameEditor({ ws, onEditWs }) {
  const [editing, setEditing] = useState(false);
  const [val, setVal] = useState(ws.name);
  const inputRef = useRef(null);

  useEffect(() => { setVal(ws.name); }, [ws.name]);

  function startEdit() {
    setVal(ws.name);
    setEditing(true);
    setTimeout(() => { inputRef.current?.select(); }, 20);
  }

  function commit() {
    const trimmed = val.trim();
    if (trimmed && trimmed !== ws.name) onEditWs(ws.id, trimmed);
    setEditing(false);
  }

  function handleKey(e) {
    if (e.key === "Enter") commit();
    if (e.key === "Escape") setEditing(false);
  }

  if (editing) {
    return (
      <input
        ref={inputRef}
        className="ws-name-input"
        value={val}
        onChange={e => setVal(e.target.value)}
        onBlur={commit}
        onKeyDown={handleKey}
        autoFocus
      />
    );
  }

  return (
    <span
      className="ws-name"
      onDoubleClick={startEdit}
      onClick={e => e.detail === 2 && startEdit()}
      onKeyDown={e => (e.key === "Enter" || e.key === " ") && startEdit()}
      tabIndex={0}
      role="button"
      aria-label={`Workstream name: ${ws.name}. Press Enter to rename.`}
      title="Double-click or press Enter to rename"
    >
      {ws.name}
    </span>
  );
}

// ─── GanttChart ───────────────────────────────────────────────────────────────
function GanttChart({ workstreams, features, filterWs, filterStatus, onEdit, onAddFeature, onEditWs, onRenameWs, density, isDark, onFeaturesChange }) {
  const [collapsed, setCollapsed] = useState({});
  const [labelWidth, setLabelWidth] = useState(LABEL_WIDTH);
  const dragRef = useRef(null);
  const colResizeRef = useRef(null);
  const wrapRef = useRef(null);

  const colW = COL_WIDTH;
  const labW = labelWidth;
  const rowH = density === "compact" ? 28 : 36;

  const gridCols = `${labW}px ${MONTHS.map(() => colW + "px").join(" ")}`;

  // Column resize
  function handleColResizeStart(e) {
    e.preventDefault();
    e.stopPropagation();
    colResizeRef.current = { startX: e.clientX, startW: labW };
    document.body.style.cursor = "col-resize";
    document.body.style.userSelect = "none";
  }

  useEffect(() => {
    function onColMove(e) {
      if (!colResizeRef.current) return;
      const dx = e.clientX - colResizeRef.current.startX;
      setLabelWidth(Math.max(100, Math.min(360, colResizeRef.current.startW + dx)));
    }
    function onColUp() {
      if (!colResizeRef.current) return;
      colResizeRef.current = null;
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
    }
    window.addEventListener("mousemove", onColMove);
    window.addEventListener("mouseup", onColUp);
    return () => { window.removeEventListener("mousemove", onColMove); window.removeEventListener("mouseup", onColUp); };
  }, []);

  function toggleCollapse(wsId) {
    setCollapsed(c => ({ ...c, [wsId]: !c[wsId] }));
  }

  function getMonthFromX(x) {
    const rect = wrapRef.current?.getBoundingClientRect();
    if (!rect) return 0;
    const relX = x - rect.left - labW;
    return Math.max(0, Math.min(11, Math.floor(relX / colW)));
  }

  function handleDragStart(e, feature) {
    e.preventDefault();
    dragRef.current = { type: "move", featureId: feature.id, startX: e.clientX, origStart: feature.start, origEnd: feature.end };
    document.body.classList.add("is-dragging");
  }

  function handleResizeStart(e, feature, side) {
    e.preventDefault();
    dragRef.current = { type: side === "l" ? "resize-l" : "resize-r", featureId: feature.id, startX: e.clientX, origStart: feature.start, origEnd: feature.end };
    document.body.classList.add("is-dragging");
  }

  useEffect(() => {
    function onMove(e) {
      const d = dragRef.current;
      if (!d) return;
      const dx = e.clientX - d.startX;
      const monthDelta = Math.round(dx / colW);
      let ns = d.origStart, ne = d.origEnd;
      if (d.type === "move") {
        ns = Math.max(0, Math.min(11, d.origStart + monthDelta));
        ne = Math.max(0, Math.min(11, d.origEnd + monthDelta));
        if (ne - ns !== d.origEnd - d.origStart) return;
      } else if (d.type === "resize-l") {
        ns = Math.max(0, Math.min(d.origEnd, d.origStart + monthDelta));
      } else if (d.type === "resize-r") {
        ne = Math.max(d.origStart, Math.min(11, d.origEnd + monthDelta));
      }
      onFeaturesChange(prev => prev.map(f => f.id === d.featureId ? {...f, start: ns, end: ne} : f));
    }
    function onUp() {
      if (!dragRef.current) return;
      dragRef.current = null;
      document.body.classList.remove("is-dragging");
    }
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
    return () => { window.removeEventListener("mousemove", onMove); window.removeEventListener("mouseup", onUp); };
  }, [onFeaturesChange]);

  return (
    <div className="gantt-wrap" ref={wrapRef}>
      <div className="gantt" style={{minWidth: labW + colW * 12}}>

        {/* Release band */}
        <div className="gantt-release-row" style={{display:"grid", gridTemplateColumns: gridCols}}>
          <div className="release-cell" />
          {MONTHS.map((_, i) => {
            const rel = RELEASES.find(r => r.start <= i && i <= r.end);
            if (rel && i === rel.start) {
              return (
                <div key={i} className="release-cell release-cell-label"
                  style={{gridColumn:`span ${rel.end - rel.start + 1}`, background: rel.bg, color: rel.color}}>
                  {rel.label}
                </div>
              );
            }
            if (!rel) return <div key={i} className="release-cell" />;
            return null;
          })}
        </div>

        {/* Month header */}
        <div className="gantt-header" style={{display:"grid", gridTemplateColumns: gridCols}}>
          <div className="month-cell" style={{textAlign:"left", paddingLeft:12, fontWeight:600, position:"relative"}}>
            Workstream / Feature
            <div
              className="col-resize-handle"
              onMouseDown={handleColResizeStart}
              title="Drag to resize"
            />
          </div>
          {MONTHS.map((m, i) => (
            <div key={i} className={`month-cell${i === CURRENT_MONTH ? " current" : ""}`}>{m}</div>
          ))}
        </div>

        {/* Workstream sections */}
        {workstreams.map(ws => {
          if (filterWs && ws.id !== filterWs) return null;
          const wsFeatures = features.filter(f =>
            f.ws === ws.id && (!filterStatus || f.status === filterStatus)
          );
          const isCollapsed = collapsed[ws.id];

          return (
            <div key={ws.id} className="ws-section">
              {/* WS Header */}
              <div className="ws-header" style={{display:"grid", gridTemplateColumns: gridCols}}>
                <div className="ws-header-cell">
                  <button
                  className="ws-collapse-btn"
                  onClick={() => toggleCollapse(ws.id)}
                  aria-label={isCollapsed ? `Expand ${ws.name}` : `Collapse ${ws.name}`}
                  aria-expanded={!isCollapsed}
                >
                    <span className={`ws-chevron${isCollapsed ? " collapsed" : ""}`}>▾</span>
                  </button>
                  <div className="ws-actions">
                    <button onClick={() => onAddFeature(ws.id)}>+ feature</button>
                  </div>
                  <span className="ws-dot" style={{background: ws.color}} />
                  <WsNameEditor ws={ws} onEditWs={onRenameWs} />
                </div>
                {MONTHS.map((_, i) => {
                  const rel = RELEASES.find(r => r.start <= i && i <= r.end);
                  return <div key={i} className="ws-header-month" style={{background: rel ? rel.bg + "44" : undefined}} />;
                })}
              </div>

              {/* Feature rows */}
              {!isCollapsed && wsFeatures.map(f => (
                <div key={f.id} className="feature-row" style={{display:"grid", gridTemplateColumns: gridCols, height: rowH}}>
                  <div className="feature-label">
                    <span className="drag-handle">⠿</span>
                    <span className="feature-name" onClick={() => onEdit(f.id)}>{f.name}</span>
                  </div>
                  {MONTHS.map((_, i) => {
                    const rel = RELEASES.find(r => r.start <= i && i <= r.end);
                    return (
                      <div key={i}
                        className={`cell${i % 2 ? " alt" : ""}`}
                        style={{background: rel ? rel.bg + "33" : undefined}}
                        onClick={() => !dragRef.current && i !== f.start && i !== f.end}
                      >
                        {i === f.start && (
                          <GanttBar
                            feature={f}
                            colWidth={colW}
                            onEdit={onEdit}
                            onDragStart={handleDragStart}
                            onResizeStart={handleResizeStart}
                            isDark={isDark}
                            density={density}
                          />
                        )}
                      </div>
                    );
                  })}
                </div>
              ))}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─── FeatureModal ─────────────────────────────────────────────────────────────
function FeatureModal({ open, feature, workstreams, onSave, onDelete, onClose }) {
  const [name, setName] = useState("");
  const [ws, setWs] = useState("");
  const [status, setStatus] = useState("not-started");
  const [start, setStart] = useState(0);
  const [end, setEnd] = useState(0);

  useEffect(() => {
    if (open) {
      setName(feature?.name || "");
      setWs(feature?.ws || workstreams[0]?.id || "");
      setStatus(feature?.status || "not-started");
      setStart(feature?.start ?? 0);
      setEnd(feature?.end ?? 0);
    }
  }, [open, feature]);

  function pickStart(i) {
    setStart(i);
    if (end < i) setEnd(i);
  }
  function pickEnd(i) {
    setEnd(i);
    if (start > i) setStart(i);
  }

  function handleSave() {
    if (!name.trim()) return;
    onSave({ name: name.trim(), ws, status, start, end });
  }

  if (!open) return null;
  return (
    <div className="modal-bg" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <div className="modal-header">
          <h3>{feature ? "Edit feature" : "Add feature"}</h3>
          <button className="modal-close" onClick={onClose}>✕</button>
        </div>
        <div className="form-row">
          <label>Feature name</label>
          <input className="form-input" value={name} onChange={e => setName(e.target.value)}
            placeholder="Feature name" autoFocus onKeyDown={e => e.key === "Enter" && handleSave()} />
        </div>
        <div className="form-row">
          <label>Workstream</label>
          <select className="form-input" value={ws} onChange={e => setWs(e.target.value)}>
            {workstreams.map(w => <option key={w.id} value={w.id}>{w.name}</option>)}
          </select>
        </div>
        <div className="form-row">
          <label>Status</label>
          <select className="form-input" value={status} onChange={e => setStatus(e.target.value)}>
            {STATUSES.map(s => <option key={s.id} value={s.id}>{s.label}</option>)}
          </select>
        </div>
        <div className="form-row">
          <label>Start month</label>
          <div className="month-grid">
            {MONTHS.map((m, i) => (
              <button key={i} className={`month-btn${i === start ? " selected" : ""}`} onClick={() => pickStart(i)}>{m}</button>
            ))}
          </div>
        </div>
        <div className="form-row">
          <label>End month</label>
          <div className="month-grid">
            {MONTHS.map((m, i) => (
              <button key={i} className={`month-btn${i === end ? " selected" : ""}`} onClick={() => pickEnd(i)}>{m}</button>
            ))}
          </div>
        </div>
        <div className="modal-actions">
          {feature && <button className="btn-danger" onClick={onDelete} style={{marginRight:"auto"}}>Delete</button>}
          <button className="btn-secondary" onClick={onClose}>Cancel</button>
          <button className="btn-primary" onClick={handleSave}>Save</button>
        </div>
      </div>
    </div>
  );
}

// ─── WorkstreamModal ──────────────────────────────────────────────────────────
function WorkstreamModal({ open, ws, features, onSave, onDelete, onClose }) {
  const [name, setName] = useState("");
  const [color, setColor] = useState(WS_COLORS[0]);

  useEffect(() => {
    if (open) {
      setName(ws?.name || "");
      setColor(ws?.color || WS_COLORS[0]);
    }
  }, [open, ws]);

  function handleSave() {
    if (!name.trim()) return;
    onSave({ name: name.trim(), color });
  }

  function handleDelete() {
    const hasFeat = features.some(f => f.ws === ws?.id);
    if (hasFeat) { alert("Move or delete all features in this workstream first."); return; }
    onDelete();
  }

  if (!open) return null;
  return (
    <div className="modal-bg" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal" style={{width: 320}}>
        <div className="modal-header">
          <h3>{ws ? "Edit workstream" : "Add workstream"}</h3>
          <button className="modal-close" onClick={onClose}>✕</button>
        </div>
        <div className="form-row">
          <label>Workstream name</label>
          <input className="form-input" value={name} onChange={e => setName(e.target.value)}
            placeholder="e.g. Analytics" autoFocus onKeyDown={e => e.key === "Enter" && handleSave()} />
        </div>
        <div className="form-row">
          <label>Color</label>
          <div style={{display:"flex", gap:8, flexWrap:"wrap", marginTop:4}}>
            {WS_COLORS.map(c => (
              <button key={c} onClick={() => setColor(c)} style={{
                width:28, height:28, borderRadius:"50%", background:c, border: color === c ? "3px solid var(--text)" : "2px solid transparent",
                cursor:"pointer", padding:0
              }} />
            ))}
          </div>
        </div>
        <div className="modal-actions">
          {ws && <button className="btn-danger" onClick={handleDelete} style={{marginRight:"auto"}}>Delete</button>}
          <button className="btn-secondary" onClick={onClose}>Cancel</button>
          <button className="btn-primary" onClick={handleSave}>Save</button>
        </div>
      </div>
    </div>
  );
}

// ─── ConfirmModal ─────────────────────────────────────────────────────────────
function ConfirmModal({ open, title, body, onConfirm, onClose, danger }) {
  if (!open) return null;
  return (
    <div className="modal-bg" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal" style={{width:320}}>
        <div className="modal-header"><h3>{title}</h3></div>
        {body && <p style={{fontSize:13, color:"var(--text-secondary)", marginBottom:16}}>{body}</p>}
        <div className="modal-actions">
          <button className="btn-secondary" onClick={onClose}>Cancel</button>
          <button className={danger ? "btn-danger" : "btn-primary"} onClick={onConfirm}>{danger ? "Confirm" : "OK"}</button>
        </div>
      </div>
    </div>
  );
}

// ─── App ──────────────────────────────────────────────────────────────────────
function App({ tweaks }) {
  const saved = load();
  const [workstreams, setWorkstreams] = useState(saved?.workstreams || DEFAULT_WS);
  const [features, setFeatures] = useState(saved?.features || DEFAULT_FEATURES);
  const [nextId, setNextId] = useState(saved?.nextId || 8);
  const [roadmapName, setRoadmapName] = useState(saved?.roadmapName || "My Roadmap");
  const [filterWs, setFilterWs] = useState("");
  const [filterStatus, setFilterStatus] = useState("");

  // Modal state
  const [featureModal, setFeatureModal] = useState({ open: false, feature: null, defaultWs: null });
  const [wsModal, setWsModal] = useState({ open: false, ws: null });
  const [confirmModal, setConfirmModal] = useState({ open: false });

  const { theme = "snow", density = "comfortable" } = tweaks || {};
  const isDark = theme === "midnight" || theme === "gradient-dark";

  // Persist on state change
  useEffect(() => {
    persist({ workstreams, features, nextId, roadmapName });
  }, [workstreams, features, nextId, roadmapName]);

  // Apply theme to document
  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
  }, [theme]);

  function openAddFeature(wsId) {
    setFeatureModal({ open: true, feature: null, defaultWs: wsId });
  }
  function openEditFeature(fid) {
    const f = features.find(x => x.id === fid);
    if (f) setFeatureModal({ open: true, feature: f, defaultWs: null });
  }
  function saveFeature(data) {
    if (featureModal.feature) {
      setFeatures(prev => prev.map(f => f.id === featureModal.feature.id ? {...f, ...data} : f));
    } else {
      const wsId = data.ws || featureModal.defaultWs || workstreams[0]?.id;
      setFeatures(prev => [...prev, { id: nextId, ...data, ws: wsId }]);
      setNextId(n => n + 1);
    }
    setFeatureModal({ open: false, feature: null, defaultWs: null });
  }
  function deleteFeature() {
    setFeatures(prev => prev.filter(f => f.id !== featureModal.feature.id));
    setFeatureModal({ open: false, feature: null, defaultWs: null });
  }

  function openAddWs() { setWsModal({ open: true, ws: null }); }
  function openEditWs(wsId) {
    const ws = workstreams.find(w => w.id === wsId);
    if (ws) setWsModal({ open: true, ws });
  }
  function renameWs(wsId, newName) {
    setWorkstreams(prev => prev.map(w => w.id === wsId ? {...w, name: newName} : w));
  }
  function saveWs(data) {
    if (wsModal.ws) {
      setWorkstreams(prev => prev.map(w => w.id === wsModal.ws.id ? {...w, ...data} : w));
    } else {
      const id = data.name.toLowerCase().replace(/\s+/g, "-") + "-" + Date.now();
      setWorkstreams(prev => [...prev, { id, ...data }]);
    }
    setWsModal({ open: false, ws: null });
  }
  function deleteWs() {
    setWorkstreams(prev => prev.filter(w => w.id !== wsModal.ws.id));
    setWsModal({ open: false, ws: null });
  }

  function handleNew() {
    setConfirmModal({
      open: true, title: "Start new roadmap?",
      body: "Any unsaved changes will be lost.",
      danger: true,
      onConfirm: () => {
        setWorkstreams(DEFAULT_WS);
        setFeatures(DEFAULT_FEATURES);
        setNextId(8);
        setRoadmapName("My Roadmap");
        setConfirmModal({ open: false });
      }
    });
  }

  function handleExportJson() {
    const data = { name: roadmapName, workstreams, features, nextId, exportedAt: new Date().toISOString() };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `${roadmapName.replace(/[^a-z0-9]/gi,"-")}-roadmap.json`; a.click();
    URL.revokeObjectURL(url);
  }

  function handleImportJson(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      try {
        const data = JSON.parse(ev.target.result);
        if (!data.workstreams || !data.features) throw new Error("Invalid");
        setWorkstreams(data.workstreams);
        setFeatures(data.features);
        setNextId(data.nextId || 100);
        setRoadmapName(data.name || "Imported Roadmap");
      } catch(_) { alert("Invalid roadmap file."); }
    };
    reader.readAsText(file);
    e.target.value = "";
  }

  return (
    <div className="app-shell">
      <TopBar
        roadmapName={roadmapName}
        onNameChange={setRoadmapName}
        onNew={handleNew}
        onSave={() => persist({ workstreams, features, nextId, roadmapName })}
        onExportJson={handleExportJson}
        onImportJson={handleImportJson}
        theme={theme}
      />
      <div className="app-body">
        <StatsBar features={features} />
        <Toolbar
          workstreams={workstreams}
          onAddFeature={openAddFeature}
          onAddWs={openAddWs}
          filterWs={filterWs} setFilterWs={setFilterWs}
          filterStatus={filterStatus} setFilterStatus={setFilterStatus}
          onExportPptx={() => alert("PPTX export — wire up pptxgenjs in production.")}
        />
        <Legend />
        <GanttChart
          workstreams={workstreams}
          features={features}
          filterWs={filterWs}
          filterStatus={filterStatus}
          onEdit={openEditFeature}
          onAddFeature={openAddFeature}
          onEditWs={openEditWs}
          onRenameWs={renameWs}
          density={density}
          isDark={isDark}
          onFeaturesChange={setFeatures}
        />
      </div>

      <FeatureModal
        open={featureModal.open}
        feature={featureModal.feature}
        workstreams={workstreams}
        onSave={saveFeature}
        onDelete={deleteFeature}
        onClose={() => setFeatureModal({ open: false, feature: null, defaultWs: null })}
      />
      <WorkstreamModal
        open={wsModal.open}
        ws={wsModal.ws}
        features={features}
        onSave={saveWs}
        onDelete={deleteWs}
        onClose={() => setWsModal({ open: false, ws: null })}
      />
      <ConfirmModal
        {...confirmModal}
        onClose={() => setConfirmModal({ open: false })}
      />
    </div>
  );
}

Object.assign(window, { App });
